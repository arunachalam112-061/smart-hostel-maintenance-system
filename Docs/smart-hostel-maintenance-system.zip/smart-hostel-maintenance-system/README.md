# Smart Hostel Maintenance System

A full-stack starter project for managing hostel maintenance complaints.

## Technology
- Backend: Java 17+, Spring Boot 3, Spring Web, Spring Data JPA, Spring Security, H2 (easy local testing)
- Frontend: HTML, CSS, JavaScript
- Database: H2 by default; `database/schema.sql` and `sample-data.sql` are provided for MySQL-style deployment

## Features in this starter
- Register and login API
- Create/list/update maintenance complaints
- Staff/admin complaint views and status updates
- Notifications and feedback API scaffolds
- Responsive frontend pages
- SQL schema and project documentation

> This is a starter implementation for academic/demo use, not a production-ready security system. Before production, add proper password hashing, JWT/session authentication, role-based authorization, validation, audit logging, and database credentials via environment variables.

## Run backend
1. Install JDK 17+ and Maven.
2. Open a terminal in `backend/smart-hostel`.
3. Run `mvn spring-boot:run`.
4. API base URL: `http://localhost:8080/api`
5. H2 console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:hosteldb`, user: `sa`, blank password).

If Maven Wrapper files are absent, use installed Maven. The wrapper scripts are included as placeholders; regenerate a standard wrapper with `mvn wrapper:wrapper` if needed.

## Run frontend
Open `frontend/index.html` in a browser, or serve the `frontend` folder with VS Code Live Server. The frontend calls `http://localhost:8080/api`.

## Demo API endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/complaints`
- `POST /api/complaints`
- `PATCH /api/complaints/{id}/status`
- `GET /api/notifications`
- `POST /api/feedback`

## Project structure
See `Docs/` for the overview, architecture, database design, API documentation, and UML class diagram notes.
