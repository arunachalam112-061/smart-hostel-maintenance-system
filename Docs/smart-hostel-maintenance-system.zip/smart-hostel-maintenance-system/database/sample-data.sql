-- Demo users only. For real use, never store plain-text passwords.
INSERT INTO users (name,email,password,phone,role) VALUES
('Demo Student','student@example.com','DemoPass123','9000000001','STUDENT'),
('Demo Staff','staff@example.com','DemoPass123','9000000002','STAFF'),
('Demo Admin','admin@example.com','DemoPass123','9000000003','ADMIN');
