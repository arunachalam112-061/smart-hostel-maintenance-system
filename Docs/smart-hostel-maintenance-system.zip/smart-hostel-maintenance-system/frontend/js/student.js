// Student dashboard shares the complaint list widget.
if(document.getElementById('complaintsList')) loadComplaints?.();
