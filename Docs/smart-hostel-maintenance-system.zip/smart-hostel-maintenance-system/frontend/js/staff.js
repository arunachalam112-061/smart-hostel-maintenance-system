async function loadComplaints(){
 const target=document.getElementById('complaintsList');if(!target)return;
 try{
  const items=await apiRequest('/staff/work');
  target.innerHTML=items.length?items.map(c=>`<article class="complaint-item"><div class="complaint-meta"><h3>#${c.id} · ${escapeHtml(c.title)}</h3><span class="pill">${escapeHtml(c.status)}</span></div><p>${escapeHtml(c.description)} · ${escapeHtml(c.location)}</p><label>Update status<select id="status-${c.id}"><option>OPEN</option><option>ASSIGNED</option><option>IN_PROGRESS</option><option>RESOLVED</option><option>REJECTED</option></select></label><button class="btn" onclick="updateStatus(${c.id})">Save status</button></article>`).join(''):'<div class="empty">No work items found.</div>';
 }catch(err){target.innerHTML=`<div class="empty">${escapeHtml(err.message)}. Is the backend running?</div>`;}
}
async function updateStatus(id){try{await apiRequest(`/complaints/${id}/status`,{method:'PATCH',body:JSON.stringify({status:document.getElementById(`status-${id}`).value,note:'Updated by staff'})});alert('Status updated');loadComplaints();}catch(e){alert(e.message)}}
document.getElementById('refreshComplaints')?.addEventListener('click',loadComplaints);
loadComplaints();
