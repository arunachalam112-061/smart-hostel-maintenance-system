async function loadAdminSummary(){try{const x=await apiRequest('/admin/summary');const el=document.getElementById('adminSummary');if(el)el.textContent=`Registered users: ${x.userCount}`;}catch(e){console.warn(e.message)}}
loadAdminSummary();
