async function loadComplaints(){
 const target=document.getElementById('complaintsList'); if(!target)return;
 try{
  const items=await apiRequest('/complaints');
  target.innerHTML=items.length?items.map(c=>`<article class="complaint-item"><div class="complaint-meta"><h3>#${c.id} · ${escapeHtml(c.title)}</h3><span class="pill">${escapeHtml(c.status)}</span></div><p>${escapeHtml(c.description)}</p><p><b>Category:</b> ${escapeHtml(c.category)} · <b>Location:</b> ${escapeHtml(c.location)}</p><p><small>Created: ${escapeHtml(c.createdAt||'')}</small></p></article>`).join(''):'<div class="empty">No complaints yet.</div>';
 }catch(err){target.innerHTML=`<div class="empty">Could not load complaints: ${escapeHtml(err.message)}. Is the backend running?</div>`;}
}
document.getElementById('refreshComplaints')?.addEventListener('click',loadComplaints);
document.getElementById('complaintForm')?.addEventListener('submit',async e=>{
 e.preventDefault();
 try{
  const data={title:document.getElementById('title').value,description:document.getElementById('description').value,category:document.getElementById('category').value,location:document.getElementById('location').value,studentId:document.getElementById('studentId').value?Number(document.getElementById('studentId').value):null};
  const result=await apiRequest('/complaints',{method:'POST',body:JSON.stringify(data)});
  showMessage(`Complaint #${result.id} submitted successfully.`,true); e.target.reset();
 }catch(err){showMessage(err.message);}
});
loadComplaints();
