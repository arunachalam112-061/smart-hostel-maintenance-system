document.getElementById('loginForm')?.addEventListener('submit', async e => {
 e.preventDefault();
 const emailValue=document.getElementById('email').value, passwordValue=document.getElementById('password').value;
 try {
  const user = await apiRequest('/auth/login',{method:'POST',body:JSON.stringify({email:emailValue,password:passwordValue})});
  localStorage.setItem('hostelUser',JSON.stringify(user)); showMessage('Login successful. Redirecting…',true);
  setTimeout(()=>location.href=user.role==='ADMIN'?'admin-dashboard.html':user.role==='STAFF'?'staff-dashboard.html':'student-dashboard.html',600);
 } catch(err){showMessage(err.message);}
});
document.getElementById('registerForm')?.addEventListener('submit',async e=>{
 e.preventDefault();
 const val=id=>document.getElementById(id).value;
 try{
  await apiRequest('/auth/register',{method:'POST',body:JSON.stringify({name:val('name'),email:val('email'),password:val('password'),phone:val('phone'),role:val('role')})});
  showMessage('Account created. You can now log in.',true);
 }catch(err){showMessage(err.message);}
});
