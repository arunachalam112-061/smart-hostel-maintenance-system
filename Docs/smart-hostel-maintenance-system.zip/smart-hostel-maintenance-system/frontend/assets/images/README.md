Place licensed hostel-related photos here using these filenames if desired:
- hostel-building.jpg
- hostel-room.jpg
- hostel-interior.jpg
- maintenance-work.jpg
- electrician.jpg
- plumbing-work.jpg
- cleaning-work.jpg

The UI uses emoji/illustrations by default so the project works without external image assets.
