@echo off
REM Placeholder: install Maven or regenerate Maven Wrapper with mvn wrapper:wrapper
mvn %*
