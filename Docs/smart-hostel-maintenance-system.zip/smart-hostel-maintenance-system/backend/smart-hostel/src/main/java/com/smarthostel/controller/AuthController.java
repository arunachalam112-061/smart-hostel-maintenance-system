package com.smarthostel.controller;
import com.smarthostel.dto.*;
import com.smarthostel.model.User;
import com.smarthostel.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api/auth")
public class AuthController {
 private final AuthService service;
 public AuthController(AuthService service){this.service=service;}
 @PostMapping("/register") public Map<String,Object> register(@Valid @RequestBody RegisterRequest r){return safe(service.register(r));}
 @PostMapping("/login") public Map<String,Object> login(@Valid @RequestBody LoginRequest r){return safe(service.login(r));}
 private Map<String,Object> safe(User u){return Map.of("id",u.getId(),"name",u.getName(),"email",u.getEmail(),"role",u.getRole().name(),"message","Success");}
}
