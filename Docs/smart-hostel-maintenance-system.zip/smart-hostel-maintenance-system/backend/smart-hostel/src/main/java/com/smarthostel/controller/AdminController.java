package com.smarthostel.controller;
import com.smarthostel.model.User;
import com.smarthostel.repository.UserRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/admin")
public class AdminController {
 private final UserRepository users;
 public AdminController(UserRepository users){this.users=users;}
 @GetMapping("/users") public List<User> users(){return users.findAll().stream().map(u->{u.setPassword(null);return u;}).toList();}
 @GetMapping("/summary") public java.util.Map<String,Object> summary(){return java.util.Map.of("userCount",users.count(),"message","Smart Hostel Maintenance System");}
}
