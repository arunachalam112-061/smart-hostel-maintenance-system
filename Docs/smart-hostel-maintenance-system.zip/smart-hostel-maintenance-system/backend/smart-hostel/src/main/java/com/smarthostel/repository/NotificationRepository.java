package com.smarthostel.repository;
import com.smarthostel.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
 
}
