package com.smarthostel.service;
import com.smarthostel.model.Notification;
import com.smarthostel.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class NotificationService {
 private final NotificationRepository repository;
 public NotificationService(NotificationRepository repository){this.repository=repository;}
 public List<Notification> all(){return repository.findAll();}
}
