package com.smarthostel.controller;
import com.smarthostel.dto.*;
import com.smarthostel.model.Complaint;
import com.smarthostel.service.ComplaintService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/complaints")
public class ComplaintController {
 private final ComplaintService service;
 public ComplaintController(ComplaintService service){this.service=service;}
 @GetMapping public List<Complaint> all(){return service.all();}
 @GetMapping("/{id}") public Complaint get(@PathVariable Long id){return service.get(id);}
 @PostMapping public Complaint create(@Valid @RequestBody ComplaintRequest r){return service.create(r);}
 @PatchMapping("/{id}/status") public Complaint status(@PathVariable Long id,@Valid @RequestBody StatusRequest r){return service.updateStatus(id,r);}
}
