package com.smarthostel.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Complaint {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    @Column(length=2000) private String description;
    private String category;
    private String location;
    @Enumerated(EnumType.STRING) private ComplaintStatus status = ComplaintStatus.OPEN;
    private Long studentId;
    private Long assignedStaffId;
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();

    @PreUpdate public void onUpdate(){ updatedAt=LocalDateTime.now(); }
    public Complaint() {}
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getTitle(){return title;} public void setTitle(String title){this.title=title;}
    public String getDescription(){return description;} public void setDescription(String description){this.description=description;}
    public String getCategory(){return category;} public void setCategory(String category){this.category=category;}
    public String getLocation(){return location;} public void setLocation(String location){this.location=location;}
    public ComplaintStatus getStatus(){return status;} public void setStatus(ComplaintStatus status){this.status=status;}
    public Long getStudentId(){return studentId;} public void setStudentId(Long studentId){this.studentId=studentId;}
    public Long getAssignedStaffId(){return assignedStaffId;} public void setAssignedStaffId(Long assignedStaffId){this.assignedStaffId=assignedStaffId;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime createdAt){this.createdAt=createdAt;}
    public LocalDateTime getUpdatedAt(){return updatedAt;} public void setUpdatedAt(LocalDateTime updatedAt){this.updatedAt=updatedAt;}
}
