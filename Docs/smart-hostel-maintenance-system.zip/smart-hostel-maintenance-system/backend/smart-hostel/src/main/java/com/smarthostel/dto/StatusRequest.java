package com.smarthostel.dto;
import com.smarthostel.model.ComplaintStatus;
import jakarta.validation.constraints.NotNull;
public record StatusRequest(@NotNull ComplaintStatus status, Long assignedStaffId, String note) {}
