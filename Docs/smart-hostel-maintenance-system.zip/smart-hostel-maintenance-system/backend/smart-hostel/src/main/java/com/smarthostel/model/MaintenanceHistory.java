package com.smarthostel.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity
public class MaintenanceHistory {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private Long complaintId; private String status; private String note; private LocalDateTime changedAt=LocalDateTime.now();
 public MaintenanceHistory(){} public MaintenanceHistory(Long complaintId,String status,String note){this.complaintId=complaintId;this.status=status;this.note=note;}
 public Long getId(){return id;} public Long getComplaintId(){return complaintId;} public String getStatus(){return status;}
 public String getNote(){return note;} public LocalDateTime getChangedAt(){return changedAt;}
}
