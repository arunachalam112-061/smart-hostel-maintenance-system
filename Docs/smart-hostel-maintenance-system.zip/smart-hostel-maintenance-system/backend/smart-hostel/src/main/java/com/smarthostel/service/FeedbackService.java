package com.smarthostel.service;
import com.smarthostel.dto.FeedbackRequest;
import com.smarthostel.model.Feedback;
import com.smarthostel.repository.FeedbackRepository;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class FeedbackService {
 private final FeedbackRepository repository;
 public FeedbackService(FeedbackRepository repository){this.repository=repository;}
 public Feedback create(FeedbackRequest r){return repository.save(new Feedback(r.complaintId(),r.userId(),r.rating(),r.comments()));}
 public List<Feedback> all(){return repository.findAll();}
}
