package com.smarthostel.controller;
import com.smarthostel.model.Notification;
import com.smarthostel.service.NotificationService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/notifications")
public class NotificationController {
 private final NotificationService service;
 public NotificationController(NotificationService service){this.service=service;}
 @GetMapping public List<Notification> all(){return service.all();}
}
