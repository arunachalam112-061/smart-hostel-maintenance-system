package com.smarthostel.dto;
import com.smarthostel.model.Role;
import jakarta.validation.constraints.*;
public record RegisterRequest(@NotBlank String name, @Email @NotBlank String email,
 @NotBlank String password, String phone, Role role) {}
