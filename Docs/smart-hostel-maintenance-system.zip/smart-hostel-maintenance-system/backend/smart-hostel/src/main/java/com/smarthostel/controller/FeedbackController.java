package com.smarthostel.controller;
import com.smarthostel.dto.FeedbackRequest;
import com.smarthostel.model.Feedback;
import com.smarthostel.service.FeedbackService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/feedback")
public class FeedbackController {
 private final FeedbackService service;
 public FeedbackController(FeedbackService service){this.service=service;}
 @GetMapping public List<Feedback> all(){return service.all();}
 @PostMapping public Feedback create(@Valid @RequestBody FeedbackRequest r){return service.create(r);}
}
