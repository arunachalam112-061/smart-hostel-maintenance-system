package com.smarthostel.service;
import com.smarthostel.dto.*;
import com.smarthostel.model.*;
import com.smarthostel.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.util.List;
@Service
public class ComplaintService {
 private final ComplaintRepository complaints; private final MaintenanceHistoryRepository history;
 private final NotificationRepository notifications;
 public ComplaintService(ComplaintRepository c, MaintenanceHistoryRepository h, NotificationRepository n){complaints=c;history=h;notifications=n;}
 public List<Complaint> all(){return complaints.findAll();}
 public Complaint get(Long id){return complaints.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Complaint not found"));}
 public Complaint create(ComplaintRequest r){
  Complaint c=new Complaint(); c.setTitle(r.title()); c.setDescription(r.description()); c.setCategory(r.category());
  c.setLocation(r.location()); c.setStudentId(r.studentId()); c.setStatus(ComplaintStatus.OPEN);
  Complaint saved=complaints.save(c); history.save(new MaintenanceHistory(saved.getId(),"OPEN","Complaint submitted"));
  if(saved.getStudentId()!=null) notifications.save(new Notification(saved.getStudentId(),"Complaint #"+saved.getId()+" submitted successfully."));
  return saved;
 }
 public Complaint updateStatus(Long id, StatusRequest r){
  Complaint c=get(id); c.setStatus(r.status()); if(r.assignedStaffId()!=null)c.setAssignedStaffId(r.assignedStaffId());
  Complaint saved=complaints.save(c); history.save(new MaintenanceHistory(id,r.status().name(),r.note()==null?"Status updated":r.note()));
  if(saved.getStudentId()!=null)notifications.save(new Notification(saved.getStudentId(),"Complaint #"+id+" status: "+r.status()));
  return saved;
 }
}
