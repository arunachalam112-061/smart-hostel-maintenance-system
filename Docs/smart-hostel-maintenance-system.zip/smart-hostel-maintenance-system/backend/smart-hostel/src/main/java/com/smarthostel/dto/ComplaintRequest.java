package com.smarthostel.dto;
import jakarta.validation.constraints.*;
public record ComplaintRequest(@NotBlank String title, @NotBlank String description,
 @NotBlank String category, @NotBlank String location, Long studentId) {}
