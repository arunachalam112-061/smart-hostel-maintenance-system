package com.smarthostel.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity
public class Notification {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private Long userId; private String message; private boolean readFlag=false;
 private LocalDateTime createdAt=LocalDateTime.now();
 public Notification(){} public Notification(Long userId,String message){this.userId=userId;this.message=message;}
 public Long getId(){return id;} public Long getUserId(){return userId;} public void setUserId(Long v){userId=v;}
 public String getMessage(){return message;} public void setMessage(String v){message=v;}
 public boolean isReadFlag(){return readFlag;} public void setReadFlag(boolean v){readFlag=v;}
 public LocalDateTime getCreatedAt(){return createdAt;}
}
