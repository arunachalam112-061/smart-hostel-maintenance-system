package com.smarthostel.service;
import org.springframework.stereotype.Service;
@Service
public class AssignmentService {
 // Extend this service with workload-based staff assignment rules.
 public String strategy(){ return "Manual staff assignment is supported through the status API."; }
}
