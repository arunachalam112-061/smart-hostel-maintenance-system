package com.smarthostel.service;
import com.smarthostel.dto.*;
import com.smarthostel.model.*;
import com.smarthostel.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
@Service
public class AuthService {
 private final UserRepository users;
 public AuthService(UserRepository users){this.users=users;}
 public User register(RegisterRequest r){
  if(users.findByEmail(r.email()).isPresent()) throw new ResponseStatusException(HttpStatus.CONFLICT,"Email already registered");
  User u=new User(r.name(),r.email(),r.password(),r.phone(),r.role()==null?Role.STUDENT:r.role());
  return users.save(u);
 }
 public User login(LoginRequest r){
  User u=users.findByEmail(r.email()).orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid email or password"));
  if(!u.getPassword().equals(r.password())) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid email or password");
  return u;
 }
}
