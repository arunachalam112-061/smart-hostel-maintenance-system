package com.smarthostel.repository;
import com.smarthostel.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface UserRepository extends JpaRepository<User, Long> {
 java.util.Optional<User> findByEmail(String email);
}
