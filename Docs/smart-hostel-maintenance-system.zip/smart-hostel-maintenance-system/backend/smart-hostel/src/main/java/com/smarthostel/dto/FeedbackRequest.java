package com.smarthostel.dto;
import jakarta.validation.constraints.*;
public record FeedbackRequest(@NotNull Long complaintId, @NotNull Long userId,
 @Min(1) @Max(5) int rating, String comments) {}
