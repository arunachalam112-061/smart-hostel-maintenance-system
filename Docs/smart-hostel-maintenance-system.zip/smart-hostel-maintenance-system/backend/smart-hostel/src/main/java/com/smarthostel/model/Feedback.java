package com.smarthostel.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
@Entity
public class Feedback {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private Long complaintId; private Long userId; private int rating;
 @Column(length=1000) private String comments; private LocalDateTime createdAt=LocalDateTime.now();
 public Feedback(){} public Feedback(Long complaintId,Long userId,int rating,String comments){this.complaintId=complaintId;this.userId=userId;this.rating=rating;this.comments=comments;}
 public Long getId(){return id;} public Long getComplaintId(){return complaintId;} public Long getUserId(){return userId;}
 public int getRating(){return rating;} public String getComments(){return comments;} public LocalDateTime getCreatedAt(){return createdAt;}
}
