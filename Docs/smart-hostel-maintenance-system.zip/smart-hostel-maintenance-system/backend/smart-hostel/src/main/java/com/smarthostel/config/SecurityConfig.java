package com.smarthostel.config;

// Security is intentionally not enforced in this academic starter.
// Add Spring Security, password hashing, sessions/JWT, and role-based rules before production.
public class SecurityConfig {
}
