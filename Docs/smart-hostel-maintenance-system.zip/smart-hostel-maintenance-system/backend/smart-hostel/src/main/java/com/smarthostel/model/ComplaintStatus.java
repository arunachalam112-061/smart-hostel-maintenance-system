package com.smarthostel.model;
public enum ComplaintStatus { OPEN, ASSIGNED, IN_PROGRESS, RESOLVED, REJECTED }
