package com.smarthostel.controller;
import com.smarthostel.model.Complaint;
import com.smarthostel.service.ComplaintService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/staff")
public class StaffController {
 private final ComplaintService complaints;
 public StaffController(ComplaintService complaints){this.complaints=complaints;}
 @GetMapping("/work") public List<Complaint> work(){return complaints.all();}
}
