package com.smarthostel.model;
public enum Role { STUDENT, STAFF, ADMIN }
