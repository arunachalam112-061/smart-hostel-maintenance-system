Regenerate standard Maven Wrapper files using `mvn wrapper:wrapper` if required.
